<?php
   include('header.php');
   
   if(isset($_POST['submit']))
   {
   $hname=$_POST['hname'];
   $fname=$_POST['fname'];
   $uname=$_POST['uname'];
   $email=$_POST['email'];
   $password=md5($_POST['npass']);
   $sql=mysqli_query($db,"insert into admin(hospital_name,fullName,username,email,password) values('$hname','$fname','$username','$email','$password')");
   if($sql)
   {
   echo "<script>alert('Hospital Admin info added Successfully');</script>";
   echo "<script type='text/javascript'> document.location = 'location:manage-doctors.php'; </script>";
   
   }
   }
   ?>
<script type="text/javascript">
   function valid()
   {
    if(document.adddoc.npass.value!= document.adddoc.cfpass.value)
   {
   alert("Password and Confirm Password Field do not match  !!");
   document.adddoc.cfpass.focus();
   return false;
   }
   return true;
   }
</script>
<!-- end: TOP NAVBAR -->
<div class="main-content" >
   <div class="wrap-content container" id="container">
      <!-- start: PAGE TITLE -->
      <section id="page-title">
         <div class="row">
            <div class="col-sm-8">
               <h1 class="mainTitle">Admin | Add Doctor</h1>
            </div>
            <ol class="breadcrumb">
               <li>
                  <span>Admin</span>
               </li>
               <li class="active">
                  <span>Add Doctor</span>
               </li>
            </ol>
         </div>
      </section>
      <!-- end: PAGE TITLE -->
      <!-- start: BASIC EXAMPLE -->
      <div class="container-fluid container-fullw bg-white">
         <div class="row">
            <div class="col-md-12">
               <div class="row margin-top-30">
                  <div class="col-lg-8 col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading">
                           <h5 class="panel-title">Add Admin</h5>
                        </div>
                        <div class="panel-body">
                           <form role="form" name="adddoc" method="post" onSubmit="return valid();">
                              
                              
                              <div class="form-group">
                                 <label for="address">
                                 Hospital Name
                                 </label>
                                 <textarea name="hname" class="form-control"  placeholder="Enter Hospital Name"></textarea>
                              </div>
                              <div class="form-group">
                                 <label for="fess">
                                 FullName
                                 </label>
                                 <input type="text" name="fname" class="form-control"  placeholder="Enter Admin FullName">
                              </div>
                              <div class="form-group">
                                 <label for="fess">
                                 UserName
                                 </label>
                                 <input type="text" name="uname" class="form-control"  placeholder="Enter Admin UserName">
                              </div>
                              <div class="form-group">
                                 <label for="fess">
                                 Email
                                 </label>
                                 <input type="email" name="email" class="form-control"  placeholder="Enter Admin Email id">
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputPassword1">
                                 Password
                                 </label>
                                 <input type="password" name="npass" class="form-control"  placeholder="New Password" required="required">
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputPassword2">
                                 Confirm Password
                                 </label>
                                 <input type="password" name="cfpass" class="form-control"  placeholder="Confirm Password" required="required">
                              </div>
                              <button type="submit" name="submit" class="btn btn-o btn-primary">
                              Submit
                              </button>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-lg-12 col-md-12">
               <div class="panel panel-white">
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<!-- start: FOOTER -->
<?php include('footer.php');?>
<!-- end: FOOTER -->