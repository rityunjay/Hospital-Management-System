<div class="app-content">
   <?php include('header.php');?>
   <!-- end: TOP NAVBAR -->
   <div class="main-content" >
      <div class="wrap-content container" id="container">
         <!-- start: PAGE TITLE -->
         <section id="page-title">
            <div class="row">
               <div class="col-sm-8">
                  <h1 class="mainTitle">Admin | Dashboard</h1>
               </div>
               <ol class="breadcrumb">
                  <li>
                     <span>Admin</span>
                  </li>
                  <li class="active">
                     <span>Dashboard</span>
                  </li>
               </ol>
            </div>
         </section>
         <!-- end: PAGE TITLE -->
         <!-- start: BASIC EXAMPLE -->
         <div class="container-fluid container-fullw bg-white">
            <div class="row">
               <div class="col-sm-4">
                  <div class="panel panel-white no-radius text-center">
                     <div class="panel-body">
                        <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-smile-o fa-stack-1x fa-inverse"></i> </span>
                        <h2 class="StepTitle">Patients List</h2>
                        <p class="links cl-effect-1">
                           <a href="users-list.php">
                           <?php $result = mysqli_query($db,"SELECT * FROM users ");
                              $num_rows = mysqli_num_rows($result);
                              {
                              ?>
                           Total Patients :<?php echo $num_rows;  } ?>		
                           </a>
                        </p>
                     </div>
                  </div>
               </div>
               <div class="col-sm-4">
                  <div class="panel panel-white no-radius text-center">
                     <div class="panel-body">
                        <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-users fa-stack-1x fa-inverse"></i> </span>
                        <h2 class="StepTitle">Doctors List</h2>
                        <p class="cl-effect-1">
                           <a href="doctor-list.php">
                           <?php $result1 = mysqli_query($db,"SELECT * FROM doctors ");
                              $num_rows1 = mysqli_num_rows($result1);
                              {
                              ?>
                           Total Doctors :<?php echo $num_rows1;  } ?>
						   
                           </a>
                        </p>
                     </div>
                  </div>
               </div>
               <?php /*<div class="col-sm-4">
                  <div class="panel panel-white no-radius text-center">
                     <div class="panel-body">
                        <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-terminal fa-stack-1x fa-inverse"></i> </span>
                        <h2 class="StepTitle"> Hospital List</h2>
                        <p class="links cl-effect-1">
                           <a href="book-appointment.php">
                           <a href="appointment-history.php">
                           <?php $sql= mysqli_query($db,"SELECT * FROM hospital");
                              $num_rows2 = mysqli_num_rows($sql);
                              {
                              ?>
                           Total Appointments :<?php echo $num_rows2;  } ?>	
                           </a>
                           </a>
                        </p>
                     </div>
                  </div>
               </div>*/?>
            </div>
         </div>
         <!-- end: SELECT BOXES -->
      </div>
   </div>
</div>
<!-- start: FOOTER -->
<?php include('footer.php');?>
<!-- end: FOOTER -->