<?php
// initializing variables
$name = "";
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'hms_db') or die("Could not connect database");
?>