<?php
   session_start();
   //error_reporting(0);
   include("../inc/config.php");

   // LOGIN USER
if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
  	array_push($errors, "Username or Email is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }
  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM users WHERE (username='$username' or email='$username') AND password='$password'";
  	$results = mysqli_query($db, $query);
	$num=mysqli_fetch_assoc($results);
	
	if($num>0){
	   $extra="dashboard.php";//
	   $_SESSION['login']=$_POST['username'];
	   $_SESSION['id']=$num['id'];
	   $host=$_SERVER['HTTP_HOST'];
	   $uip=$_SERVER['REMOTE_ADDR'];
	   $status=1;
	   $log=mysqli_query($db,"insert into userlog(uid,username,userip,status) values('".$_SESSION['id']."','".$_SESSION['login']."','$uip','$status')");
	   $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
	   header("location:http://$host$uri/$extra");
	   exit();
	   }else{
	   $_SESSION['login']=$_POST['username'];	
	   $uip=$_SERVER['REMOTE_ADDR'];
	   $status=0;
	   mysqli_query($db,"insert into userlog(username,userip,status) values('".$_SESSION['login']."','$uip','$status')");
	   $_SESSION['errmsg']="Invalid username or password";
	   $extra="login.php";
	   $host  = $_SERVER['HTTP_HOST'];
	   $uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
	   header("location:http://$host$uri/$extra");
	   exit();
	   }
	
  }
}
   ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	
	<link rel="stylesheet" href="../assets/css/style.css">

    <title>Login | Hospital Management</title>
  </head>
  <body>
	<div class="bg-image">
		<div class="">
			<div id="login">
				<div class="container">
					<div id="login-row" class="row justify-content-center align-items-center">
						<div class="col-md-8">
							
						</div>
						<div id="login-column" class="col-md-4">
							<div id="login-box" class="col-md-12">
								<form id="login-form" class="form" action="" method="post">
									<h3 class="text-center text-info" style="font-weight: 700;font-size: 30px;margin-bottom:10px;">Login</h3>
									<?php include('../inc/errors.php'); ?>
									<div class="form-group ">
										<label for="username" class="text-info">Username or Email:</label><br>
										<input type="text" name="username" id="username" class="form-control">
											
									</div>
									<div class="form-group">
										<label for="password" class="text-info">Password:</label><br>
										<input type="password" name="password" id="password" class="form-control">
											
									</div>
									<div class="form-group">
										<a href="forgot-password.php" class="text-info" style="position:relative;top:-8px;">Forgot Password</a><br>
										<input type="submit" name="login_user" class="btn btn-info btn-md" value="Login">
									</div>
									<div id="register-link" class="text-right">
										<a href="register.php#" class="text-info" style="position:relative;top:10px;">Register Here!</a>
									</div>										
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

    <!-- Optional JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>