<footer>
   <div class="footer-inner">
      <!--<div class="pull-left">
         &copy; <span class="current-year"></span><span class="text-bold text-uppercase"> HMS</span>. <span>Developed By <a href="#">Rityunjay</a></span>
      </div>-->
      <div class="pull-right">
         <span class="go-top"><i class="ti-angle-up"></i></span>
      </div>
   </div>
</footer>
<!-- end: SETTINGS -->
</div>
<!-- start: MAIN JAVASCRIPTS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/additional-methods.js"></script>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/login.js"></script>
<script>
   jQuery(document).ready(function() {
   	Main.init();
   	FormElements.init();
   });
</script>
<!-- end: JavaScript Event Handlers for this page -->
<!-- end: CLIP-TWO JAVASCRIPTS -->
</body>
</html>