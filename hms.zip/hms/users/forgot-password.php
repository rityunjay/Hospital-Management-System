<?php
include_once('../inc/config.php');
$error='';
$rsent='';
$additionalheaders='';
//This code runs if the form has been submitted
if (isset($_POST['submit']))
{
 
// check for valid email address
$email = $_POST['email'];
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
     $error = "<p style='color:red;'>Please enter a valid email address</p>";
}
 
// checks if the username is in use
$check = mysqli_query($db,"SELECT email FROM users WHERE email = '$email'");
$check2 =mysqli_num_rows($check);
 
 
//if the name exists it gives an error
if ($check2 == 0) {
$error = "<p style='color:red;'>Sorry, Your emails doesn't exists in our record</p>";
}

if (!$error) {
 
$query = mysqli_query($db,"SELECT username FROM users WHERE email = '$email' ");
$r=mysqli_fetch_object($query);
 
//create a new random password
 
$password = substr(md5(uniqid(rand(),1)),3,10);
$pass = md5($password); //encrypted version for database entry
 
//send email
$to = "$email";
$subject = "Account Details Recovery";
$body = "Hi $r->username, nn you or someone else have requested your account details. nn Here is your account information please keep this as you may need this at a later stage. nnYour username is $r->username nn your password is $password nn Your password has been reset please login and change your password to something more rememberable.nn Regards Site Admin";
$lheaders= "From: <contact@domain.com>rn";
$lheaders.= "Reply-To: noprely@domain.com";
mail($to, $subject, $body, $additionalheaders);
 
//update database
$sql = mysqli_query($db,"UPDATE users SET password='$pass' WHERE email = '$email'");
$rsent = true;
 
 
}// close errors
}// close if form sent
 
//show any errors
/*if (!empty($error))
{
        $i = 0;
        while ($i < count($error)){
        echo "<div class='error-msg'>".$error[$i]."</div>";
        $i ++;}
}// close if empty errors
*/
 
if ($rsent == true){
    $error = "<p style='color:green;'>Just sent an email with your account details to $email</p>";
    } else {
    $msg = "<p style='color:red;'>Please enter your e-mail address. You will receive a new password via e-mail.</p>";
    }
 
?>
 


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	
	<link rel="stylesheet" href="../assets/css/style.css">

    <title>Registration | Hospital Management</title>
  </head>
  <body>
	<div class="bg-image">
		<div class="">
			<div id="login">
				<div class="container">
					<div id="login-row" class="row justify-content-center align-items-center">
						<div class="col-md-8">
							     
						</div>
						<div id="login-column" class="col-md-4">
							<div id="login-box" class="col-md-12">
							
								<form id="login-form" class="form" action="" method="post">
								<h3 class="text-center text-info" style="font-weight: 700;font-size: 30px;margin-bottom:10px;">Forgot Password</h3>
								<?php echo $error;?>
									<div class="form-group">
										<label for="text" class="text-info">Your Email:</label><br>
										<input type="text" name="email" id="email" class="form-control">
									</div>
									<div class="form-group">								
										<input type="submit" name="submit" class="btn btn-info btn-md" value="Register">
									</div>
									<div id="register-link" class="text-right">
										<a href="login.php" class="text-info" style="position:relative;top:45px;">Login Here!</a>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	

    <!-- Optional JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>