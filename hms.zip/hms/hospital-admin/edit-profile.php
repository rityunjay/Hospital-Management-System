<?php
   include('header.php');
   if(isset($_POST['submit']))
   {
   $hname=$_POST['hname'];
   $fname=$_POST['fname'];
   $address=$_POST['address'];
   $city=$_POST['city'];
   $phone=$_POST['phone'];
   $gender=$_POST['gender'];

   $sql=mysqli_query($db,"Update admin set hospital_name='$hname', fullName='$fname',address='$address',city='$city',phone='$phone',gender='$gender' where id='".$_SESSION['id']."'");
   if($sql)
   {
   echo "<script>alert('Your Profile updated Successfully');</script>";
   
   }
   }
   ?>
   
<!-- end: TOP NAVBAR -->
<div class="main-content" >
   <div class="wrap-content container" id="container">
      <!-- start: PAGE TITLE -->
      <section id="page-title">
         <div class="row">
            <div class="col-sm-8">
               <h1 class="mainTitle">Admin | Edit Profile</h1>
            </div>
            <ol class="breadcrumb">
               <li>
                  <span>User </span>
               </li>
               <li class="active">
                  <span>Edit Profile</span>
               </li>
            </ol>
         </div>
      </section>
      <!-- end: PAGE TITLE -->
      <!-- start: BASIC EXAMPLE -->
      <div class="container-fluid container-fullw bg-white">
         <div class="row">
            <div class="col-md-12">
               <div class="row margin-top-30">
                  <div class="col-lg-8 col-md-12">
                     <div class="panel panel-white">
                        <div class="panel-heading">
                           <h5 class="panel-title">Edit Profile</h5>
                        </div>
                        <div class="panel-body">
							<?php $sql=mysqli_query($db,"select * from admin where id='".$_SESSION['id']."'");
                              while($data=mysqli_fetch_array($sql))
                              {
								 //User profile picture
								$userPicture = !empty($row['picture'])?$row['picture']:'no-image.png';
								$userPictureURL = 'uploads/images/'.$userPicture;
                              ?>
							<form role="form" name="edit" method="post">
								<div class="form-group">
									<label for="fname">Hosptial Name</label>
									<input type="text" name="hname" class="form-control" value="<?php echo mysqli_real_escape_string($db,$data['hospital_name']);?>" >
								</div>
								<div class="form-group">
									<label for="fname">Full Name</label>
									<input type="text" name="fname" class="form-control" value="<?php echo mysqli_real_escape_string($db,$data['fullName']);?>" >
								</div>
								<div class="form-group">
									<label for="fname">User Name</label>
									<input type="text" name="uname" class="form-control" readonly="readonly" value="<?php echo mysqli_real_escape_string($db,$data['username']);?>" >
								</div>
								<div class="form-group">
									<label for="address">Address</label>
									<textarea name="address" class="form-control"><?php echo mysqli_real_escape_string($db,$data['address']);?></textarea>
								</div>
								<div class="form-group">
									<label for="city">City</label>
									<input type="text" name="city" class="form-control" required="required"  value="<?php echo mysqli_real_escape_string($db,$data['city']);?>" >
								</div>
								<div class="form-group">
									<label for="fname">Phone</label>
									<input type="text" name="phone" class="form-control" value="<?php echo mysqli_real_escape_string($db,$data['phone']);?>" >
								</div>
								<div class="form-group">
									<label for="gender">Gender</label>
									<div class="clip-radio radio-primary">
										<input type="radio" id="rg-female" name="gender" value="female" <?php if($data['gender']=="female"){ echo "checked";}?>>
										<label for="rg-female">Female</label>
										<input type="radio" id="rg-male" name="gender" value="male" <?php if($data['gender']=="male"){ echo "checked";}?>>
										<label for="rg-male">Male</label>
									</div>
								</div>
								<div class="form-group">
									<label for="fess">User Email</label>
									<input type="email" name="email" class="form-control"  readonly="readonly"  value="<?php echo mysqli_real_escape_string($db,$data['email']);?>">
									<?php /*if($data['email_status']!=0){
										echo 'Email Verified!';
									}else {?>
									<a href="">Email Verify</a>
									<?php }*/?>
								</div>
                        
								<button type="submit" name="submit" class="btn btn-o btn-primary">Update</button>
							</form>
						<?php } ?>

						</div>
                     </div>
                  </div>
					<div class="col-lg-4">
					<?php $sql=mysqli_query($db,"select * from admin where id='".$_SESSION['id']."'");
                        while($data=mysqli_fetch_array($sql))
                        {
						//User profile picture
						$userPicture = !empty($row['logo'])?$row['logo']:'logo/no-image.png';
						$userPictureURL = 'logo/'.$userPicture;
						}
                    ?>	
					<h3 style="text-align: center;text-transform: uppercase;font-size: 22px;">Change Logo</h3>
					<div class="user-box">
						<div class="img-relative">
							<!-- Loading image -->
							<div class="overlay uploadProcess" style="display: none;">
								<div class="overlay-content"><img src="images/loading.gif"/></div>
							</div>
							<!-- Hidden upload form -->
							<form method="post" action="upload.php" enctype="multipart/form-data" id="picUploadForm" target="uploadTarget">
								<input type="file" name="logo" id="fileInput"  style="display:none"/>
							</form>
							<iframe id="uploadTarget" name="uploadTarget" src="#" style="width:0;height:0;border:0px solid #fff;"></iframe>
							<!-- Image update link -->
							<a class="editLink" href="javascript:void(0);"><img src="../assets/images/edit.png"/></a>
							<!-- Profile image -->
							<img src="<?php echo $userPictureURL; ?>" id="imagePreview">
						</div>
						
					</div>
	
					</div>
			   </div>
            </div>
         </div>
         <div class="col-lg-12 col-md-12">
            <div class="panel panel-white">
            </div>
         </div>
      </div>
   </div>
   <!-- end: BASIC EXAMPLE -->
   <!-- end: SELECT BOXES -->
</div>
</div>
</div>
<!-- start: FOOTER -->
<?php include('footer.php');?>
<!-- end: FOOTER -->