<?php
include('header.php');
?>

<div class="main-content" >
   <div class="wrap-content container" id="container">
      <!-- start: PAGE TITLE -->
      <section id="page-title">
         <div class="row">
            <div class="col-sm-8">
               <h1 class="mainTitle">Admin | Manage Doctors</h1>
            </div>
            <ol class="breadcrumb">
               <li>
                  <span>Admin</span>
               </li>
               <li class="active">
                  <span>Manage Doctors</span>
               </li>
            </ol>
         </div>
      </section>
      <!-- end: PAGE TITLE -->
      <!-- start: BASIC EXAMPLE -->
      <div class="container-fluid container-fullw bg-white">
         <div class="row">
            <div class="col-md-12">
               <h5 class="over-title margin-bottom-15">Search <span class="text-bold">Docters</span></h5>
				<form action="" method="post">  
					<input type="text" name="term" placeholder="Specilization" class="form-control" /><br />  
					<input type="submit" value="Submit" />  
				</form> 
               
               <table class="table table-hover" id="sample-table-1">
                  <thead>
                     <tr>
                        <th class="center">#</th>
                        <th>Specialization</th>
                        <th class="hidden-xs">Doctor Name</th>
                        <th>Doctor Fees </th>
                        <th>Doctor Email</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
						if (!empty($_REQUEST['term'])) {

						$term = mysqli_real_escape_string($db,$_REQUEST['term']);     

						$sql = "SELECT * FROM doctors WHERE specilization LIKE '%".$term."%'"; 
						$r_query = mysqli_query($db,$sql); 
						$cnt=1;
						while ($row = mysqli_fetch_array($r_query)){  
                        ?>
                     <tr>
                        <td class="center"><?php echo $cnt;?>.</td>
                        <td class="hidden-xs"><?php echo $row['specilization'];?></td>
                        <td><?php echo $row['doctorName'];?></td>
                        <td><?php echo $row['docFees'];?></td>
                        <td><?php echo $row['docEmail'];?></td>
                     </tr>
                     <?php 
                        $cnt=$cnt+1;
					}}?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
 <?php
include('footer.php');
?>