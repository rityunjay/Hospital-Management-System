<?php
if(!empty($_FILES['logo']['name'])){
    //Include database configuration file
    session_start();
   //error_reporting(0);
   include('../inc/config.php');
    
    $result = 0;
    $uploadDir = "logo/";
    $logo = time().'_'.basename($_FILES['logo']['name']);
    $targetPath = $uploadDir. $logo;
    
    //Upload file to server
    if(@move_uploaded_file($_FILES['logo']['tmp_name'], $targetPath)){
        //Get current user ID from session
        //$userId = 1;
        
        //Update picture name in the database
        $update = mysqli_query($db,"UPDATE admin SET logo = '".$logo."' WHERE id = '".$_SESSION['id']."'");
        
        //Update status
        if($update){
            $result = 1;
        }
    }
    
    //Load JavaScript function to show the upload status
    echo '<script type="text/javascript">window.top.window.completeUpload(' . $result . ',\'' . $targetPath . '\');</script>  ';
}